#ifndef COORDINATES_H
#define COORDINATES_H

#include <QObject>
#include <QGeoPositionInfo>
#include <QGeoSatelliteInfo>
#include <QThread>
#include <QBasicTimer>

#include "geoposition.h"

class Coordinates : public QObject
{
    Q_OBJECT

public:
    explicit Coordinates(QObject *parent = 0);
    ~Coordinates();

signals:
    void updateCoordinates(
        const QString & coordinates,
        const QString & direction,
        const QString & speed,
        const QString & timestamp);
    void updateSatelliteCount(const QString & satelliteCount);
    void updateAntenaStatus(const QString & antenaStatus);
    void updateSatellitesInView(const QString & satellitesInView);

private slots:
    void positionUpdated(const QGeoPositionInfo& info);
    void satellitesInUseUpdated(const QList<QGeoSatelliteInfo> &satellites);
    void satellitesInViewUpdated(const QList<QGeoSatelliteInfo> &satellites);
    void antennaStatusChanged(GeoPosition::AntennaStatus antennaStatus);

private:
    QThread _uiThread;
};

#endif // COORDINATES_H
