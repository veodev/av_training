#include <QCoreApplication>

#include "coordinates.h"

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    Coordinates coordinates;

//    freopen("/dev/console", "w", stdout);
//    freopen("/dev/console", "w", stderr);
//    freopen("/dev/console", "r", stdin);

    // for ssh terminal
    ::setenv("TERM", "xterm");
    freopen("/dev/pts/0", "w", stdout);
    freopen("/dev/pts/0", "w", stderr);
    freopen("/dev/pts/0", "r", stdin);

    return a.exec();
}
