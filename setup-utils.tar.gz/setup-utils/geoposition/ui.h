#ifndef UI_H
#define UI_H

#include <QObject>
#include <QString>

class Ui : public QObject
{
    Q_OBJECT

public:
    Ui(QObject * parent = 0);
    ~Ui();

public slots:
    void setCoordinates(
        const QString & coordinates,
        const QString & direction,
        const QString & speed,
        const QString & timestamp);
    void setSatelliteCount(const QString & satelliteCount);
    void setAntenaStatus(const QString & antenaStatus);
    void setSatellitesInView(const QString & satellitesInView);

    void init();
    void finit();
    void update();

private slots:
    void readyRead();

private:
    bool _isScreenInited;
    void * _listitems;
    QString _coordinates;
    QString _direction;
    QString _speed;
    QString _timestamp;
    QString _satelliteCount;
    QString _antenaStatus;
    QString _satellitesInView;
};

#endif // UI_H
