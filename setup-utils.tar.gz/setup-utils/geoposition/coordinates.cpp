#include <QtNumeric>
#include <QTimerEvent>

#include "coordinates.h"
#include "debug.h"

#include <ncurses.h>
#include "ui.h"

#include <stdio.h>
using namespace std;

Coordinates::Coordinates(QObject * parent) :
    QObject(parent)
{
    GeoPosition * geoPosition = GeoPosition::instance("/dev/ttymxc2");
    ASSERT(connect(geoPosition, &GeoPosition::positionUpdated, this, &Coordinates::positionUpdated));
    ASSERT(connect(geoPosition, &GeoPosition::satellitesInUseUpdated, this, &Coordinates::satellitesInUseUpdated));
    ASSERT(connect(geoPosition, &GeoPosition::satellitesInViewUpdated, this, &Coordinates::satellitesInViewUpdated));
    ASSERT(connect(geoPosition, &GeoPosition::antennaStatusChanged, this, &Coordinates::antennaStatusChanged));

    Ui * ui = new Ui;
    ui->moveToThread(&_uiThread);
    ASSERT(connect(&_uiThread, &QThread::finished, ui, &Ui::finit));
    ASSERT(connect(&_uiThread, &QThread::finished, ui, &QObject::deleteLater));
    ASSERT(connect(&_uiThread, &QThread::started, ui, &Ui::init));
    ASSERT(connect(this, &Coordinates::updateCoordinates, ui, &Ui::setCoordinates));
    ASSERT(connect(this, &Coordinates::updateAntenaStatus, ui, &Ui::setAntenaStatus));
    ASSERT(connect(this, &Coordinates::updateSatelliteCount, ui, &Ui::setSatelliteCount));
    ASSERT(connect(this, &Coordinates::updateSatellitesInView, ui, &Ui::setSatellitesInView));
    _uiThread.start();
}

Coordinates::~Coordinates()
{
    _uiThread.exit();
    _uiThread.wait();
}

void Coordinates::positionUpdated(const QGeoPositionInfo &info)
{
    QString coordinateString("---");
    QString directionString("---");
    QString speedString("---");
    QString timestampString("---");

    QGeoCoordinate coordinate = info.coordinate();
    if (coordinate.type() == QGeoCoordinate::Coordinate2D)
       coordinateString = coordinate.toString(QGeoCoordinate::DegreesMinutesSecondsWithHemisphere);

    qreal direction = info.attribute(QGeoPositionInfo::Direction);
    if (::qIsNaN(direction) == false) {
        directionString = QString::number(direction);
    }

    qreal speed = info.attribute(QGeoPositionInfo::GroundSpeed);
    if (::qIsNaN(speed) == false) {
        speedString = QString::number(speed);
    }

    timestampString = info.timestamp().toString(Qt::LocaleDate);

    emit updateCoordinates(coordinateString, directionString, speedString, timestampString);
}

void Coordinates::satellitesInUseUpdated(const QList<QGeoSatelliteInfo> &satellites)
{
    if (satellites.count() > 0 && satellites.at(0).satelliteSystem() == QGeoSatelliteInfo::GPS) {
        emit updateSatelliteCount(QString::number(satellites.count()));
    }
}

void Coordinates::satellitesInViewUpdated(const QList<QGeoSatelliteInfo> &satellites)
{
    QString satellitesInView("Satellite Id:Strength\n---------------------\n");

    if (satellites.count() && (satellites.at(0).satelliteSystem() == QGeoSatelliteInfo::GPS)) {
        for (int i = 0; i < satellites.count(); ++i) {
            satellitesInView.append(QString::number(satellites.at(i).satelliteIdentifier()) + ":" + QString::number(satellites.at(i).signalStrength()) + "\r\n");
        }
    }

    emit updateSatellitesInView(satellitesInView);
}

void Coordinates::antennaStatusChanged(GeoPosition::AntennaStatus antennaStatus)
{
    QString status;

    switch (antennaStatus) {
    case GeoPosition::AntennaStatusUnknown:
        status = "Unknown status";
        break;
    case GeoPosition::AntennaStatusConnected:
        status = "Connected";
        break;
    case GeoPosition::AntennaStatusDisconnected:
        status = "Disconnected";
        break;
    default:
        status = "Unknown status";
        break;
    }

    emit updateAntenaStatus(status);
}
