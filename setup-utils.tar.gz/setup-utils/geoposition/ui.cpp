#include <QSocketNotifier>
#include <QCoreApplication>

#include <ncurses.h>
#include <ncurses/panel.h>

#include "dialog.h"
#include "ui.h"

Ui::Ui(QObject * parent)
    : QObject(parent)
    , _isScreenInited(false)
    , _listitems(0)
    , _coordinates("---")
    , _direction("---")
    , _speed("---")
    , _timestamp("---")
    , _satelliteCount("---")
    , _antenaStatus("---")
    , _satellitesInView("")
{
    connect(new QSocketNotifier(0, QSocketNotifier::Read, this),
        SIGNAL(activated(int)), SLOT(readyRead()));
    readyRead();
}

Ui::~Ui()
{
}

void Ui::setCoordinates(
        const QString & coordinates,
        const QString & direction,
        const QString & speed,
        const QString & timestamp)
{
    _coordinates = coordinates;
    _direction == direction;
    _speed = speed;
    _timestamp = timestamp;

    update();
}

void Ui::setSatelliteCount(const QString &satelliteCount)
{
    _satelliteCount = satelliteCount;

    update();
}

void Ui::setAntenaStatus(const QString &antenaStatus)
{
    _antenaStatus = antenaStatus;

    update();
}

void Ui::setSatellitesInView(const QString &satellitesInView)
{
    _satellitesInView = satellitesInView;

    update();
}

void Ui::init()
{
    initscr();
    cbreak();
    raw();
    nonl();
    noecho();
    curs_set(0);
    keypad(stdscr, TRUE);
    nodelay(stdscr, true);
    start_color();

    _isScreenInited = true;

    _listitems = (void *)new DIALOG_FORMITEM[6];
    DIALOG_FORMITEM *listitems = static_cast<DIALOG_FORMITEM *>(_listitems);

    listitems[0].name = (char *)("Coordinates");
    listitems[1].name = (char *)("Direction");
    listitems[2].name = (char *)("Speed (m/s)");
    listitems[3].name = (char *)("Timestamp");
    listitems[4].name = (char *)("Satellites");
    listitems[5].name = (char *)("Antena status");

    for (int i = 0; i < 6; ++i) {
        listitems[i].type = dialog_vars.formitem_type;
        listitems[i].name_len = ::strlen(listitems[i].name);
        listitems[i].name_y = i;
        listitems[i].name_x = 1;
        listitems[i].name_free = false;
        listitems[i].text_y = i;
        listitems[i].text_x = 15;
        listitems[i].text_flen = 0;
        listitems[i].text_ilen = 20;
        listitems[i].text_free = false;
        listitems[i].help = (char *)("");
        listitems[i].help_free = false;
    }

    ::memset(&dialog_state, 0, sizeof(dialog_state));
    ::memset(&dialog_vars, 0, sizeof(dialog_vars));

    dialog_state.output = stderr;
    dialog_state.input = stdin;

    dialog_vars.dlg_clear_screen = TRUE;
    dialog_vars.begin_set = TRUE;
    dialog_vars.nocancel = true;
    dialog_vars.ok_label = (char *)("Close");

    dialog_vars.title = (char *)("Geoposition");
    dialog_vars.keep_tite = true;
    dialog_vars.backtitle = (char *)("Avicon-14");

    init_dialog(dialog_state.input, dialog_state.output);
    dlg_put_backtitle();

    update();
}

void Ui::finit()
{
    if (_listitems) {
        delete [] static_cast<DIALOG_FORMITEM *>(_listitems);
    }
    echo();
    curs_set(1);
    endwin();
    _isScreenInited = false;
}

void Ui::update()
{
    DIALOG_FORMITEM *listitems = static_cast<DIALOG_FORMITEM *>(_listitems);

    QByteArray coordinates = _coordinates.toLocal8Bit();
    listitems[0].text = coordinates.data();
    listitems[0].text_len = coordinates.length();
    QByteArray direction = _direction.toLocal8Bit();
    listitems[1].text = direction.data();
    listitems[1].text_len = direction.length();
    QByteArray speed = _speed.toLocal8Bit();
    listitems[2].text = speed.data();
    listitems[2].text_len = speed.length();
    QByteArray timestamp = _timestamp.toLocal8Bit();
    listitems[3].text = timestamp.data();
    listitems[3].text_len = timestamp.length();
    QByteArray satelliteCount = _satelliteCount.toLocal8Bit();
    listitems[4].text = satelliteCount.data();
    listitems[4].text_len = satelliteCount.length();
    QByteArray antenaStatus = _antenaStatus.toLocal8Bit();
    listitems[5].text = antenaStatus.data();
    listitems[5].text_len = antenaStatus.length();

    dialog_vars.begin_x = 3;
    dialog_vars.begin_y = 17;
    QByteArray satellitesInView = _satellitesInView.toLocal8Bit();
    dialog_msgbox("Satellites in view", satellitesInView.data(), 12, 50, 0);

    dialog_vars.begin_x = 3;
    dialog_vars.begin_y = 3;
    dlg_info_form("Coordinates", "", 12, 50, 0, 6, listitems);
}

void Ui::readyRead()
{
    if (_isScreenInited) {
        int c;
        while ((c = getch()) != ERR) {
            if (c == 0x0d /* key enter */ || c == 0x1b /* key escape */ ) {
                QCoreApplication::quit();
            }
        }
    }
}
