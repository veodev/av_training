#include <stdio.h>

#include "utsvupowermanagement.h"

int main(int argc, char *argv[])
{
    Q_UNUSED(argc);
    Q_UNUSED(argv);

    int rc = -1;

    UtsvuPowermanagement powerManager;
    if (powerManager.isSupported() && powerManager.update()) {
        ::fprintf(stdout, "%f", powerManager.batteryVoltage());
        rc = 0;
    }

    return rc;
}
