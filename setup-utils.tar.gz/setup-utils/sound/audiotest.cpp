#include "audiotest.h"
#include "debug.h"
#include "ui.h"

AudioTest::AudioTest(QObject *parent) :
    QObject(parent)
{
    _uiThread.setObjectName("Ui thread");
    Ui *ui = new Ui;
    ui->moveToThread(&_uiThread);
    ASSERT(connect(&_uiThread, &QThread::finished, ui, &Ui::finit));
    ASSERT(connect(&_uiThread, &QThread::finished, ui, &QObject::deleteLater));
    ASSERT(connect(&_uiThread, &QThread::started, ui, &Ui::init));
    _uiThread.start();
}

AudioTest::~AudioTest()
{
    _uiThread.exit();
    _uiThread.wait();
}
