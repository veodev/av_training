#include <QCoreApplication>

#include "audiotest.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    AudioTest audioTest;

    return a.exec();
}
