#ifndef UI_H
#define UI_H

#include <QObject>
#include <QString>
#include <QThread>

#include "audiooutput.h"

class Ui : public QObject
{
    Q_OBJECT

public:
    Ui(QObject * parent = 0);
    ~Ui();

public slots:
    void init();
    void finit();
    void update();

signals:
    void doPlay();
    void doStop();
    void doSetVolume(double);
    void doSetTone(AudioGenerator::Tone);
    void doClearTone(AudioGenerator::Tone);

private slots:
    void readyRead();

private:
    void showMenu();
    void showVolume();
    void showChecklist();
    void setCheckListStates(char **list, bool *states, int itemNo);
    void play();

private:
    bool _isScreenInited;
    int _volumePercents;
    int _menuChoice;
    int _ChecklistCurrentItem;
    static const int _checkListitemNo = 8;
    bool _checkListStates[_checkListitemNo];

    AudioOutput *_audioOutput;
    QThread _audioOutputThread;
};

#endif // UI_H
