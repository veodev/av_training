#include <QSocketNotifier>
#include <QCoreApplication>
#include <QDebug>

#include <ncurses.h>
#include <ncurses/panel.h>

#include "dialog.h"
#include "ui.h"
#include "debug.h"

Ui::Ui(QObject * parent)
    : QObject(parent)
    , _isScreenInited(false)
    , _volumePercents(50)
    , _menuChoice(-1)
    , _ChecklistCurrentItem(0)
    , _audioOutput(new AudioOutput())
{
    for (int i = 0; i < _checkListitemNo; ++i) {
        _checkListStates[i] = false;
    }

    _audioOutputThread.setObjectName("Audio output thread");
    _audioOutput->moveToThread(&_audioOutputThread);
    ASSERT(connect(&_audioOutputThread, &QThread::finished, _audioOutput, &QObject::deleteLater));
    ASSERT(connect(this, SIGNAL(doPlay()), _audioOutput, SLOT(play())));
    ASSERT(connect(this, SIGNAL(doStop()), _audioOutput, SLOT(stop())));
    ASSERT(connect(this, SIGNAL(doSetVolume(double)), _audioOutput, SLOT(setVolume(double))));
    ASSERT(connect(this, SIGNAL(doSetTone(AudioGenerator::Tone)), _audioOutput, SLOT(setTone(AudioGenerator::Tone))));
    ASSERT(connect(this, SIGNAL(doClearTone(AudioGenerator::Tone)), _audioOutput, SLOT(clearTone(AudioGenerator::Tone))));
    _audioOutputThread.start();

    emit doSetVolume(_volumePercents);

    QObject::connect(new QSocketNotifier(0, QSocketNotifier::Read, this),
        SIGNAL(activated(int)), SLOT(readyRead()));
    readyRead();
}

Ui::~Ui()
{
    _audioOutputThread.exit();
    _audioOutputThread.wait();
}

void Ui::init()
{
    initscr();
    cbreak();
    raw();
    nonl();
    noecho();
    curs_set(0);
    keypad(stdscr, TRUE);
    nodelay(stdscr, true);
    start_color();

    _isScreenInited = true;

    ::memset(&dialog_state, 0, sizeof(dialog_state));
    ::memset(&dialog_vars, 0, sizeof(dialog_vars));

    dialog_state.output = stderr;
    dialog_state.input = stdin;

    dialog_vars.dlg_clear_screen = TRUE;
    dialog_vars.begin_set = TRUE;
    dialog_vars.nocancel = false;
    dialog_vars.ok_label = (char *)"Ok";
    dialog_vars.cancel_label = (char *)"Close";

    dialog_vars.title = (char *)"Audio test";
    dialog_vars.keep_tite = true;
    dialog_vars.backtitle = (char *)"Avicon-14";

    init_dialog(dialog_state.input, dialog_state.output);
    dlg_put_backtitle();

    update();
}

void Ui::finit()
{
    echo();
    curs_set(1);
    endwin();
    _isScreenInited = false;
}

void Ui::update()
{
    showMenu();
    QCoreApplication::quit();
}

void Ui::readyRead()
{
    if (_isScreenInited) {
        int c;
        while ((c = getch()) != ERR) {
            if (c == 0x1b /* key escape */ ) {
                QCoreApplication::quit();
            }
        }
    }
}

void Ui::showMenu()
{
    const char * menu[] = {
        "1", "Set valume",
        "2", "Test audio"
    };
    int rc = 0;

    do
    {
        dialog_vars.begin_x = 3;
        dialog_vars.begin_y = 3;
        dialog_vars.ok_label = (char *)"Ok";

        dlg_clear();
        refresh();
        dlg_put_backtitle();

        rc = dialog_menu("menu", "select menu item", 9, 24, 2, 2, (char **)menu, &_menuChoice);
        if (rc == 0 && _menuChoice != -1) {
            switch (_menuChoice) {
            case 0:
                showVolume();
                break;
            case 1:
                showChecklist();
                break;
            default:
                break;
            }
        }
        else {
            break;
        }
    }
    while(rc == 0);
}

void Ui::showVolume()
{
    dialog_vars.begin_x = 5;
    dialog_vars.begin_y = 5;

    bool isStop = false;
    int ch = -1;
    do {
        ch = 13;
        dialog_gauge2("Volume", "Prompt", 5, 30, _volumePercents, &ch);

        switch(ch) {
        case KEY_UP:
        case KEY_RIGHT:
            ++_volumePercents;
            break;
        case KEY_DOWN:
        case KEY_LEFT:
            --_volumePercents;
            break;
        case KEY_HOME:
            _volumePercents = 100;
            break;
        case KEY_END:
            _volumePercents = 0;
            break;
        case KEY_NPAGE:
            _volumePercents -= 10;
            break;
        case KEY_PPAGE:
            _volumePercents += 10;
            break;
        case 13:
        case KEY_EXIT:
            isStop = true;
            break;
        case 27:
            isStop = true;
            break;
        default:
            break;
        }
        if (_volumePercents > 100) {
            _volumePercents = 100;
        }
        else if (_volumePercents < 0) {
            _volumePercents = 0;
        }
        emit doSetVolume(_volumePercents);
    }
    while (isStop == false);
}

void Ui::showChecklist()
{
    char * list[] = {
        (char *)"Test 500 Hz flash", (char *)"left",  NULL,
        (char *)"Test 500 Hz flash", (char *)"right", NULL,
        (char *)"Test 500 Hz",       (char *)"left",  NULL,
        (char *)"Test 500 Hz",       (char *)"right", NULL,
        (char *)"Test 1000 Hz",      (char *)"left",  NULL,
        (char *)"Test 1000 Hz",      (char *)"right", NULL,
        (char *)"Test 2000 Hz",      (char *)"left",  NULL,
        (char *)"Test 2000 Hz",      (char *)"right", NULL
    };
    int rc = -1;

    do
    {
        setCheckListStates(list, _checkListStates, _checkListitemNo);

        dialog_vars.begin_x = 5;
        dialog_vars.begin_y = 5;
        dialog_vars.ok_label = (char *)("Play");
        dialog_vars.default_item = NULL;
        rc = dialog_checklist(
            "title",
            "Press SPACE to toggle an option on/off.",
            10 + _checkListitemNo,
            40,
            _checkListitemNo,
            _checkListitemNo,
            (char * *)list,
            FLAG_CHECK,
            _checkListStates,
            &_ChecklistCurrentItem
        );
        if (rc == 0) {
            play();
        }
    }
    while(rc == 0);
}

void Ui::setCheckListStates(char **list, bool *states, int itemNo)
{
    for (int i = 0; i < itemNo; ++i) {
        if (states[i] == true) {
            list[i*3 + 2] = (char *)"on";
        }
        else {
            list[i*3 + 2] = (char *)"off";
        }
    }
}

void Ui::play()
{
    if (_checkListStates[0] == true) {
        emit doSetTone(AudioGenerator::left500HzBlink);
    }
    else {
        emit doClearTone(AudioGenerator::left500HzBlink);
    }
    if (_checkListStates[1] == true) {
        emit doSetTone(AudioGenerator::right500HzBlink);
    }
    else {
        emit doClearTone(AudioGenerator::right500HzBlink);
    }
    if (_checkListStates[2] == true) {
        emit doSetTone(AudioGenerator::left500Hz);
    }
    else {
        emit doClearTone(AudioGenerator::left500Hz);
    }
    if (_checkListStates[3] == true) {
        emit doSetTone(AudioGenerator::right500Hz);
    }
    else {
        emit doClearTone(AudioGenerator::right500Hz);
    }
    if (_checkListStates[4] == true) {
        emit doSetTone(AudioGenerator::left1000Hz);
    }
    else {
        emit doClearTone(AudioGenerator::left1000Hz);
    }
    if (_checkListStates[5] == true) {
        emit doSetTone(AudioGenerator::right1000Hz);
    }
    else {
        emit doClearTone(AudioGenerator::right1000Hz);
    }
    if (_checkListStates[6] == true) {
        emit doSetTone(AudioGenerator::left2000Hz);
    }
    else {
        emit doClearTone(AudioGenerator::left2000Hz);
    }
    if (_checkListStates[7] == true) {
        emit doSetTone(AudioGenerator::right2000Hz);
    }
    else {
        emit doClearTone(AudioGenerator::right2000Hz);
    }
    emit doPlay();
    dialog_vars.begin_x = 7;
    dialog_vars.begin_y = 7;
    dialog_vars.ok_label = (char *)"Stop";
    dialog_msgbox("", "", 4, 20, -1);
    emit doStop();
}
