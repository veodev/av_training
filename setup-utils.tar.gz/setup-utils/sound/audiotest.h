#ifndef AUDIOTEST_H
#define AUDIOTEST_H

#include <QObject>
#include <QThread>

class AudioTest : public QObject
{
    Q_OBJECT
public:
    explicit AudioTest(QObject *parent = 0);
    ~AudioTest();

private:
    QThread _uiThread;
};

#endif // AUDIOTEST_H
