#ifndef LCDTESTFB_H
#define LCDTESTFB_H

class LcdTestFb
{
public:
    LcdTestFb();
    ~LcdTestFb();

    void setFbFilename(const char * fbFilename);

    int screenWidth();
    int screenHeight();

    int init();
    void finit();

    void fillScreen(unsigned char red, unsigned char green, unsigned char blue);
    void vline(int x, unsigned char red, unsigned char green, unsigned char blue);
    void hline(int y, unsigned char red, unsigned char green, unsigned char blue);


private:
    int _resourcesCount;
    bool _isInited;

    char * _fbFilename;
    int _fbFile;
    int _screenSize;
    int _xRes;
    int _yRes;
    int _byte_per_pixel;
    int _byte_per_line;
    unsigned short * _fb;
};

#endif // LCDTESTFB_H
