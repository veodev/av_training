#include <unistd.h>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <string.h>

using namespace std;

#include "lcdtestfb.h"

#define FUNC_INFO __PRETTY_FUNCTION__

void usage()
{
    cout << "Usage: lcdtestfb [options]" << endl;
    cout << "    --fbdev device" << endl;
    cout << "    --fillscreen r g b" << endl;
    cout << "    --gradation 'red'|'green'|'blue' 'left'|'right'|'up'|'down'" << endl;
    cout << "    --vline x r g b" << endl;
    cout << "    --hline y r g b" << endl;
}

int main(int argc, char *argv[])
{
    LcdTestFb test;

    if (argc <= 1) {
        usage();
        return 0;
    }

    int argIterator = 1;
    while (argIterator < argc) {
        if (!::strcmp(argv[argIterator], "--fbdev")) {
            if (argc < (argIterator + 2)) {
                usage();
                return -1;
            }
            test.setFbFilename(argv[argIterator + 1]);
            argIterator += 2;
        }
        else if (!::strcmp(argv[argIterator], "--fillscreen")) {
            if (argc < (argIterator + 4)) {
                usage();
                return -1;
            }
            unsigned char red   = ::atoi(argv[argIterator + 1]);
            unsigned char green = ::atoi(argv[argIterator + 2]);
            unsigned char blue  = ::atoi(argv[argIterator + 3]);
            test.fillScreen(red, green, blue);
            ::getchar();
            argIterator += 4;
        }
        else if (!::strcmp(argv[argIterator], "--gradation")) {
            if (argc < (argIterator + 3)) {
                usage();
                return -1;
            }
            bool red = false;
            bool green = false;
            bool blue = false;
            bool right = false;
            bool left = false;
            bool up = false;
            bool down = false;
            float lineWidth = 0;

            if (!::strcmp(argv[argIterator + 1], "red")) {
                red = true;
            }
            else if (!::strcmp(argv[argIterator + 1], "green")) {
                green = true;
            }
            else if (!::strcmp(argv[argIterator + 1], "blue")) {
                blue = true;
            }
            else {
                usage();
                return -1;
            }

            if (!::strcmp(argv[argIterator + 2], "right")) {
                right = true;
            }
            else if (!::strcmp(argv[argIterator + 2], "left")) {
                left = true;
            }
            else if (!::strcmp(argv[argIterator + 2], "up")) {
                up = true;
            }
            else if (!::strcmp(argv[argIterator + 2], "down")) {
                down = true;
            }
            else {
                usage();
                return -1;
            }

            int maxBrightness = (green ? 0x3f : 0x1f);

            if (up || down) {
                lineWidth = (float)test.screenHeight() / (float)(maxBrightness + 1);
            }
            else if (right || left) {
                lineWidth = (float)test.screenWidth() / (float)(maxBrightness + 1);
            }

            for (int i = 0; i <= maxBrightness; ++i) {
                for (int j = 0; j < lineWidth; ++j) {
                    int offset = (up || left) ? (maxBrightness - i) : i;
                    if (up || down) {
                        test.hline(offset * lineWidth + j, red ? i : 0, green ? i : 0, blue ? i : 0);
                    }
                    else {
                        test.vline(offset * lineWidth + j, red ? i : 0, green ? i : 0, blue ? i : 0);
                    }
                }
            }
            ::getchar();
            argIterator += 3;
        }
        else if (!::strcmp(argv[argIterator], "--vline")) {
            if (argc < (argIterator + 5)) {
                usage();
                return -1;
            }
            int           x     = ::atoi(argv[argIterator + 1]);
            unsigned char red   = ::atoi(argv[argIterator + 2]);
            unsigned char green = ::atoi(argv[argIterator + 3]);
            unsigned char blue  = ::atoi(argv[argIterator + 4]);
            test.vline(x, red, green, blue);
            ::getchar();
            argIterator += 5;
        }
        else if (!::strcmp(argv[argIterator], "--hline")) {
            if (argc < (argIterator + 5)) {
                usage();
                return -1;
            }
            int           y     = ::atoi(argv[argIterator + 1]);
            unsigned char red   = ::atoi(argv[argIterator + 2]);
            unsigned char green = ::atoi(argv[argIterator + 3]);
            unsigned char blue  = ::atoi(argv[argIterator + 4]);
            test.hline(y, red, green, blue);
            ::getchar();
            argIterator += 5;
        }
        else {
            usage();
            return -1;
        }
    }

    return 0;
}
