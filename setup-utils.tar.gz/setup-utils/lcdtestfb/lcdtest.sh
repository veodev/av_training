#!/bin/sh

WORKDIR=/usr/local/avicon-31
. ${WORKDIR}/setup-utils/setup-vars

lcdtestfb=${WORKDIR}/setup-utils/lcdtestfb

while true ; do
    $DIALOG --title "LCD screen test" \
            --begin 3 3 \
            --clear \
            --backtitle "$ts_backtitle" \
            --cancel-label "$ts_exit" \
            --menu "$ts_select_menu_item" 10 40 3 \
            "1"  "Fill screen by red" \
            "2"  "Fill screen by green" \
            "3"  "Fill screen by blue" \
            2> $stderrTempfile

    retval=$?
    choice=`cat $stderrTempfile`

    case $retval in
        0)
            case $choice in
                1)
                    retval=0
                    while [ $retval == 0 ]; do
                        $DIALOG --title "fill screen by red" \
                                --begin 3 3 \
                                --clear \
                                --backtitle "$ts_backtitle" \
                                --cancel-label "$ts_exit" \
                                --menu "$ts_select_menu_item" 17 40 10 \
                                "1"  "bit 0" \
                                "2"  "bit 1" \
                                "3"  "bit 2" \
                                "4"  "bit 3" \
                                "5"  "bit 4" \
                                "6"  "all bits" \
                                "7"  "gradation to right" \
                                "8"  "gradation to left" \
                                "9"  "gradation to up" \
                                "10" "gradation to down" \
                                2> $stderrTempfile

                        retval=$?
                        choice=`cat $stderrTempfile`

                        case $retval in
                            0)
                                case $choice in
                                    1)
                                        $lcdtestfb --fillscreen 1 0 0
                                    ;;
                                    2)
                                        $lcdtestfb --fillscreen 2 0 0
                                    ;;
                                    3)
                                        $lcdtestfb --fillscreen 4 0 0
                                    ;;
                                    4)
                                        $lcdtestfb --fillscreen 8 0 0
                                    ;;
                                    5)
                                        $lcdtestfb --fillscreen 16 0 0
                                    ;;
                                    6)
                                        $lcdtestfb --fillscreen 63 0 0
                                    ;;
                                    7)
                                        $lcdtestfb --gradation red right
                                    ;;
                                    8)
                                        $lcdtestfb --gradation red left
                                    ;;
                                    9)
                                        $lcdtestfb --gradation red up
                                    ;;
                                    10)
                                        $lcdtestfb --gradation red down
                                    ;;
                                esac
                            ;;
                        esac
                    done
                ;;
                2)
                    retval=0
                    while [ $retval == 0 ]; do
                        $DIALOG --title "fill screen by green" \
                                --begin 3 3 \
                                --clear \
                                --backtitle "$ts_backtitle" \
                                --cancel-label "$ts_exit" \
                                --menu "$ts_select_menu_item" 18 40 11 \
                                "1"  "bit 0" \
                                "2"  "bit 1" \
                                "3"  "bit 2" \
                                "4"  "bit 3" \
                                "5"  "bit 4" \
                                "6"  "bit 5" \
                                "7"  "all bits" \
                                "8"  "gradation to right" \
                                "9"  "gradation to left" \
                                "10"  "gradation to up" \
                                "11" "gradation to down" \
                                2> $stderrTempfile

                        retval=$?
                        choice=`cat $stderrTempfile`

                        case $retval in
                            0)
                                case $choice in
                                    1)
                                        $lcdtestfb --fillscreen 0 1 0
                                    ;;
                                    2)
                                        $lcdtestfb --fillscreen 0 2 0
                                    ;;
                                    3)
                                        $lcdtestfb --fillscreen 0 4 0
                                    ;;
                                    4)
                                        $lcdtestfb --fillscreen 0 8 0
                                    ;;
                                    5)
                                        $lcdtestfb --fillscreen 0 16 0
                                    ;;
                                    6)
                                        $lcdtestfb --fillscreen 0 32 0
                                    ;;
                                    7)
                                        $lcdtestfb --fillscreen 0 63 0
                                    ;;
                                    8)
                                        $lcdtestfb --gradation green right
                                    ;;
                                    9)
                                        $lcdtestfb --gradation green left
                                    ;;
                                    10)
                                        $lcdtestfb --gradation green up
                                    ;;
                                    11)
                                        $lcdtestfb --gradation green down
                                    ;;
                                esac
                            ;;
                        esac
                    done
                ;;
                3)
                    retval=0
                    while [ $retval == 0 ]; do
                        $DIALOG --title "fill screen by blue" \
                                --begin 3 3 \
                                --clear \
                                --backtitle "$ts_backtitle" \
                                --cancel-label "$ts_exit" \
                                --menu "$ts_select_menu_item" 17 40 10 \
                                "1"  "bit 0" \
                                "2"  "bit 1" \
                                "3"  "bit 2" \
                                "4"  "bit 3" \
                                "5"  "bit 4" \
                                "6"  "all bits" \
                                "7"  "gradation to right" \
                                "8"  "gradation to left" \
                                "9"  "gradation to up" \
                                "10" "gradation to down" \
                                2> $stderrTempfile

                        retval=$?
                        choice=`cat $stderrTempfile`

                        case $retval in
                            0)
                                case $choice in
                                    1)
                                        $lcdtestfb --fillscreen 0 0 1
                                    ;;
                                    2)
                                        $lcdtestfb --fillscreen 0 0 2
                                    ;;
                                    3)
                                        $lcdtestfb --fillscreen 0 0 4
                                    ;;
                                    4)
                                        $lcdtestfb --fillscreen 0 0 8
                                    ;;
                                    5)
                                        $lcdtestfb --fillscreen 0 0 16
                                    ;;
                                    6)
                                        $lcdtestfb --fillscreen 0 0 63
                                    ;;
                                    7)
                                        $lcdtestfb --gradation blue right
                                    ;;
                                    8)
                                        $lcdtestfb --gradation blue left
                                    ;;
                                    9)
                                        $lcdtestfb --gradation blue up
                                    ;;
                                    10)
                                        $lcdtestfb --gradation blue down
                                    ;;
                                esac
                            ;;
                        esac
                    done
                ;;
            esac
            ;;
        1)
            exit 0
            ;;
        255)
            exit 0
            ;;
    esac
done