#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <iostream>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <linux/mxcfb.h>

using namespace std;

#include "lcdtestfb.h"

#define FUNC_INFO __PRETTY_FUNCTION__

#define ERR (-__LINE__)
#define OK 0

LcdTestFb::LcdTestFb()
    : _resourcesCount(0)
    , _isInited(false)
    , _fbFilename(0)
    , _fbFile(0)
    , _screenSize(0)
    , _xRes(0)
    , _yRes(0)
    , _byte_per_pixel(0)
    , _byte_per_line(0)
    , _fb(0)
{
    _fbFilename = ::strdup("/dev/fb0");
}

LcdTestFb::~LcdTestFb()
{
    finit();
    if (_fbFilename) {
        ::free(_fbFilename);
    }
}

void LcdTestFb::setFbFilename(const char * fbFilename)
{
    if (::strcmp(_fbFilename, fbFilename)) {
        if (_fbFilename) {
            free(_fbFilename);
        }
        _fbFilename = ::strdup(fbFilename);
        if (_isInited) {
            finit();
        }
    }
}

int LcdTestFb::screenWidth()
{
    if (_isInited == false) {
        if (init() != OK) {
            return 0;
        }
    }

    return _xRes;
}

int LcdTestFb::screenHeight()
{
    if (_isInited == false) {
        if (init() != OK) {
            return 0;
        }
    }

    return _yRes;
}

int LcdTestFb::init()
{
    int retval;
    struct fb_var_screeninfo screenInfo;

    if ((_fbFile = open(_fbFilename, O_RDWR, 0)) < 0) {
        cerr << FUNC_INFO << "Error: unable to open" << _fbFilename;
        finit();
        return ERR;
    }
    _resourcesCount++;

    retval = ioctl(_fbFile, FBIOBLANK, FB_BLANK_UNBLANK);
    if (retval < 0)  {
        cerr << FUNC_INFO << "Error: can't unblank screen";
        finit();
        return ERR;
    }

    retval = ioctl(_fbFile, FBIOGET_VSCREENINFO, &screenInfo);
    if (retval < 0)  {
        cerr << FUNC_INFO << "Error: can't get screen info";
        finit();
        return ERR;
    }
    _screenSize = screenInfo.xres * screenInfo.yres_virtual * screenInfo.bits_per_pixel / 8;
    _xRes = screenInfo.xres;
    _yRes = screenInfo.yres;
    _byte_per_pixel = screenInfo.bits_per_pixel / 8;
    _byte_per_line = _byte_per_pixel * screenInfo.xres;

    _fb = (unsigned short *)mmap(0, _screenSize, PROT_READ | PROT_WRITE, MAP_SHARED, _fbFile, 0);
    if ((int)_fb <= 0) {
        cerr << FUNC_INFO << "Error: failed to map framebuffer device to memory";
        finit();
        return ERR;
    }
    _resourcesCount++;

    _isInited = true;
    return OK;
}

void LcdTestFb::finit()
{
    _isInited = false;

    switch(_resourcesCount) {
    case 2:
        munmap(_fb, _screenSize);
    case 1:
        close(_fbFile);
    }
}

void LcdTestFb::fillScreen(unsigned char red, unsigned char green, unsigned char blue)
{
    if (_isInited == false) {
        if (init() != OK) {
            return;
        }
    }

    unsigned short color = ((red & 0x1f) << 11) | ((green & 0x3f) << 5) | (blue & 0x1f);

    for (int i = 0; i < _screenSize/2; ++i) {
        _fb[i] = color;
    }
}

void LcdTestFb::vline(int x, unsigned char red, unsigned char green, unsigned char blue)
{
    if (_isInited == false) {
        if (init() != OK) {
            return;
        }
    }

    unsigned short color = ((red & 0x1f) << 11) | ((green & 0x3f) << 5) | (blue & 0x1f);

    for (int i = 0; i < _yRes; ++i) {
        _fb[(i * _xRes) + x] = color;
    }
}

void LcdTestFb::hline(int y, unsigned char red, unsigned char green, unsigned char blue)
{
    if (_isInited == false) {
        if (init() != OK) {
            return;
        }
    }

    unsigned short color = ((red & 0x1f) << 11) | ((green & 0x3f) << 5) | (blue & 0x1f);

    for (int i = 0; i < _xRes; ++i) {
        _fb[(y * _xRes) + i] = color;
    }
}
