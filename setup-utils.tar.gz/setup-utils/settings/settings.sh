#! /bin/sh

WORKDIR=/usr/local/avicon-31
. ${WORKDIR}/setup-utils/setup-vars

cduserialnumber=`${WORKDIR}/setup-utils/settings ~/.config/Radioavionica/avicon-31.conf get General cduserialnumber`
railroadname=`${WORKDIR}/setup-utils/settings ~/.config/Radioavionica/avicon-31.conf get General railroadname`
organization=`${WORKDIR}/setup-utils/settings ~/.config/Radioavionica/avicon-31.conf get General organization`
noisereduction=`${WORKDIR}/setup-utils/settings ~/.config/Radioavionica/avicon-31.conf get General noisereduction`
AScanPlotOptimization=`${WORKDIR}/setup-utils/settings ~/.config/Radioavionica/avicon-31.conf get General ascanplotoptimization`

returncode=$?
exec 3>&1
value=`$DIALOG --title "$ts_settings" \
        --begin 3 3 \
        --cancel-label "$ts_exit" \
        --backtitle "$ts_backtitle" \
        --insecure "$@" \
        --mixedform "" 11 60 0 \
        "$ts_cduserialnumber:"       1 1 "${cduserialnumber}"       1 30 40 0 0 \
        "$ts_railroadname:"          2 1 "${railroadname}"          2 30 40 0 0 \
        "$ts_organization:"          3 1 "${organization}"          3 30 40 0 0 \
        "$ts_noisereduction:       " 4 1 "${noisereduction}"        4 30 6  0 0 \
        "$ts_AScanPlotOptimization:" 5 1 "${AScanPlotOptimization}" 5 30 6  0 0 \
2>&1 1>&3`
returncode=$?
exec 3>&-

case $returncode in
$DIALOG_OK)
        oldIFS="$IFS"
        IFS=$'\n'
#        array=( `echo "$value" | sed -e 's/^/ /'` )
        set -- `echo "$value" | sed -e 's/^/ /'`
#        for index in "${!array[@]}"
#        do
#                array[${index}]=`echo "${array[${index}]}" | sed -e 's/^.//'`
#        done
#        cduserialnumber="${array[0]}"
#        railroadname="${array[1]}"
#        organization="${array[2]}"
#        noisereduction="${array[3]}"
#        AScanPlotOptimization="${array[4]}"
        cduserialnumber=`echo "$1" | sed -e 's/^.//'`
        railroadname=`echo "$2" | sed -e 's/^.//'`
        organization=`echo "$3" | sed -e 's/^.//'`
        noisereduction=`echo "$4" | sed -e 's/^.//'`
        AScanPlotOptimization=`echo "$5" | sed -e 's/^.//'`
        IFS="$oldIFS"
#        echo "cduserialnumber:${cduserialnumber}"
#        echo "railroadname:${railroadname}"
#        echo "organization:${organization}"
#        echo "noisereduction:${noisereduction}"
#        echo "AScanPlotOptimization:${AScanPlotOptimization}"
        ${WORKDIR}/setup-utils/settings ~/.config/Radioavionica/avicon-31.conf set General cduserialnumber ${cduserialnumber}
        ${WORKDIR}/setup-utils/settings ~/.config/Radioavionica/avicon-31.conf set General railroadname ${railroadname}
        ${WORKDIR}/setup-utils/settings ~/.config/Radioavionica/avicon-31.conf set General organization ${organization}
        ${WORKDIR}/setup-utils/settings ~/.config/Radioavionica/avicon-31.conf set General noisereduction ${noisereduction}
        ${WORKDIR}/setup-utils/settings ~/.config/Radioavionica/avicon-31.conf set General ascanplotoptimization ${AScanPlotOptimization}
        ;;
*)
        exit
        ;;
esac
