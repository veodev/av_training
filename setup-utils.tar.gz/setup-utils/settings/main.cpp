#include <QSettings>
#include <QCoreApplication>

#include <string.h>
#include <iostream>

using namespace std;

void usage()
{
    cout << "settings conf_file get|set section key [value]" << endl;
}

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    if (argc < 4) {
        usage();
        return -1;
    }

    QCoreApplication::setApplicationName("settings");

    QString confFile(argv[1]);
    QString command(argv[2]);
    QString section(argv[3]);
    QString key(argv[4]);
    QString value((argc < 5) ? "" : argv[5]);

    QSettings settings(confFile, QSettings::IniFormat, 0);
    if (section != "General") {
        settings.beginGroup(section);
    }
    if (command == "get") {
        cout << settings.value(key).toString().toStdString() << endl;
    }
    else if (command == "set") {
        settings.setValue(key, value);
    }
    if (section != "General") {
        settings.endGroup();
    }

    return 0;
}
