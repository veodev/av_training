#include <stdio.h>

#include "ds18s20.h"

int main(int argc, char *argv[])
{
    Q_UNUSED(argc);
    Q_UNUSED(argv);

    int rc = -1;
    QString error;
    Ds18s20 ds18s20;

    float temperature = ds18s20.temperature(error);
    if (error.isEmpty()) {
        ::fprintf(stdout, "%f", temperature);
        rc = 0;
    }

    return rc;
}
