#ifndef UI_H
#define UI_H

#include <QObject>
#include <QString>

class ExternalKeyboard;

class Ui : public QObject
{
    Q_OBJECT

public:
    Ui(QObject * parent = 0);
    ~Ui();

public slots:
    void init();
    void finit();
    void update();

private slots:
    void externalKeyToggled(bool isPressed, int keyCode);
    void readyRead();

private:
    bool _isScreenInited;
    void * _listitems;
    ExternalKeyboard * _externalKeyboard;
    QString _gpi0;
    QString _gpi2;
    QString _gpi3;
};

#endif // UI_H
