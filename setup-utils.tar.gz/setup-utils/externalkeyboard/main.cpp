#include <QCoreApplication>

#include "ui.h"

//#include <stdio.h>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    Ui ui;

//    freopen("/dev/console", "w", stdout);
//    freopen("/dev/console", "w", stderr);
//    freopen("/dev/console", "r", stdin);

//    printf("test!\n");

    ui.init();

    return a.exec();
}
