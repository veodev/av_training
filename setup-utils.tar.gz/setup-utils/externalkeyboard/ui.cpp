#include <QSocketNotifier>
#include <QCoreApplication>

#include "externalkeyboard.h"

#include <ncurses.h>
#include <ncurses/panel.h>

#include "dialog.h"
#include "ui.h"

Ui::Ui(QObject * parent)
    : QObject(parent)
    , _isScreenInited(false)
    , _listitems(0)
    , _externalKeyboard(0)
    , _gpi0("")
    , _gpi2("")
    , _gpi3("")
{
    connect(new QSocketNotifier(0, QSocketNotifier::Read, this),
        SIGNAL(activated(int)), SLOT(readyRead()));
    readyRead();

    _externalKeyboard = new ExternalKeyboard(this);
    connect(_externalKeyboard, SIGNAL(toggled(bool,int)), this, SLOT(externalKeyToggled(bool,int)));
}

Ui::~Ui()
{
    finit();
}

void Ui::init()
{
    initscr();
    cbreak();
    raw();
    nonl();
    noecho();
    curs_set(0);
    keypad(stdscr, TRUE);
    nodelay(stdscr, true);
    start_color();

    _isScreenInited = true;

    _listitems = (void *)new DIALOG_FORMITEM[3];
    DIALOG_FORMITEM *listitems = static_cast<DIALOG_FORMITEM *>(_listitems);

    listitems[0].name = (char *)("Bolt. stik.:");
    listitems[1].name = (char *)("Coord:      ");
    listitems[2].name = (char *)("Svar. stik.:");

    for (int i = 0; i < 3; ++i) {
        listitems[i].type = dialog_vars.formitem_type;
        listitems[i].name_len = ::strlen(listitems[i].name);
        listitems[i].name_y = i;
        listitems[i].name_x = 1;
        listitems[i].name_free = false;
        listitems[i].text_y = i;
        listitems[i].text_x = 15;
        listitems[i].text_flen = 0;
        listitems[i].text_ilen = 20;
        listitems[i].text_free = false;
        listitems[i].help = (char *)("");
        listitems[i].help_free = false;
    }

    ::memset(&dialog_state, 0, sizeof(dialog_state));
    ::memset(&dialog_vars, 0, sizeof(dialog_vars));

    dialog_state.output = stderr;
    dialog_state.input = stdin;

    dialog_vars.dlg_clear_screen = TRUE;
    dialog_vars.begin_set = TRUE;
    dialog_vars.nocancel = true;
    dialog_vars.ok_label = (char *)("Close");

    dialog_vars.title = (char *)("External keyboard");
    dialog_vars.keep_tite = true;
    dialog_vars.backtitle = (char *)("Avicon-14");

    init_dialog(dialog_state.input, dialog_state.output);
    dlg_put_backtitle();

    update();
}

void Ui::finit()
{
    if (_listitems) {
        delete [] static_cast<DIALOG_FORMITEM *>(_listitems);
    }
    echo();
    curs_set(1);
    endwin();
    _isScreenInited = false;
}

void Ui::update()
{
    DIALOG_FORMITEM *listitems = static_cast<DIALOG_FORMITEM *>(_listitems);
    if (listitems == 0) {
        return;
    }

    QByteArray gpi0       = _gpi0.toLocal8Bit();
    listitems[0].text     = gpi0.data();
    listitems[0].text_len = gpi0.length();
    QByteArray gpi2       = _gpi2.toLocal8Bit();
    listitems[1].text     = gpi2.data();
    listitems[1].text_len = gpi2.length();
    QByteArray gpi3       = _gpi3.toLocal8Bit();
    listitems[2].text     = gpi3.data();
    listitems[2].text_len = gpi3.length();

    dialog_vars.begin_x = 3;
    dialog_vars.begin_y = 3;
    dlg_info_form("External keyboard:", "", 9, 30, 0, 3, listitems);
}

void Ui::externalKeyToggled(bool isPressed, int keyCode)
{
    switch (keyCode) {
    case 0:
        _gpi0 = isPressed ? "pressed" : "released";
        break;
    case 1:
        _gpi2 = isPressed ? "pressed" : "released";
        break;
    case 2:
        _gpi3 = isPressed ? "pressed" : "released";
        break;
    }

    update();
}

void Ui::readyRead()
{
    if (_isScreenInited) {
        int c;
        while ((c = getch()) != ERR) {
            if (c == 0x0d /* key enter */ || c == 0x1b /* key escape */ ) {
                QCoreApplication::quit();
            }
        }
    }
}
