#!/bin/sh

devicesPath="/sys/bus/sdio/devices"
dirs=`ls $devicesPath`
# echo "dirs:$dirs"
for dir in $dirs
do
    deviceFile="${devicesPath}/${dir}/device"
    # echo "Device file:${deviceFile}"
    deviceId=`cat ${deviceFile}`
    # echo "Device id:${deviceId}"
    vendorFile="${devicesPath}/${dir}/vendor"
    # echo "Vendor file:${vendorFile}"
    vendorId=`cat ${vendorFile}`
    # echo "Vendor id:${vendorId}"
    
    echo -n "wl1271:"
    if [ ${vendorId} == "0x0097" ] && [ ${deviceId} == "0x4076" ]
    then
	echo "present"
    else
	echo "absent"
    fi
done
read
