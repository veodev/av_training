#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <libgen.h>
#include <linux/i2c-dev.h>

void usage(const char * programName)
{
    printf("Usage: %s value\n", programName);
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        usage(basename(argv[0]));
        return -1;
    }

    int file;
    int adapter_nr = 0; /* probably dynamically determined */
    char filename[20];
    int rc = 0;

    unsigned char brightness = atoi(argv[1]);
    printf("brightness: %d\n", brightness);

    snprintf(filename, 19, "/dev/i2c-%d", adapter_nr);
    printf("device filename: %s\n", filename);
    file = open(filename, O_RDWR);
    if (file < 0) {
        int errsv = errno;
        printf("ERROR: device file open failes: device = '%s', errno = %s\n", filename, strerror(errsv));
        exit(1);
    }

    int addr = 0x2c; /* The I2C address */
    if ((rc = ioctl(file, I2C_SLAVE, addr)) < 0) {
        int errsv = errno;
        close(file);
        printf("ERROR: set slave address faled: address = 0x%x, rc = %d, errno = %s\n", addr, rc, strerror(errsv));
        exit(1);
    }

//    while (true) {
    char buf[10];
    buf[0] = 0x00;
    buf[1] = brightness;
    if ((rc = write(file, buf, 2)) != 2) {
        int errsv = errno;
        printf("ERROR: i2c transaction failed: rc = %d, errno = %s\n", rc, strerror(errsv));
    }
    else {
        printf("Ok!\n");
    }

//    usleep(100);
//    }

    close(file);

    return 0;
}
