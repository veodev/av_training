#include <errno.h>
#include <string.h>
#include <libgen.h>
#include <sys/ioctl.h>
#include <linux/i2c-dev.h>
#include <ncurses.h>
#include <ncurses/panel.h>

#include "dialog.h"
#include "debug.h"

bool setBrightness(unsigned char brightness)
{
    int file;
    int adapter_nr = 0;
    char filename[20];
    int rc = 0;

    snprintf(filename, 19, "/dev/i2c-%d", adapter_nr);
    file = open(filename, O_RDWR);
    if (file < 0) {
        int errsv = errno;
        fprintf(stderr, "ERROR: device file open failes: device = '%s', errno = %s\n", filename, strerror(errsv));
        return false;
    }

    int addr = 0x2c; /* The I2C address */
    if ((rc = ioctl(file, I2C_SLAVE, addr)) < 0) {
        int errsv = errno;
        close(file);
        fprintf(stderr, "ERROR: set slave address faled: address = 0x%x, rc = %d, errno = %s\n", addr, rc, strerror(errsv));
        return false;
    }

    char buf[10];
    buf[0] = 0x00;
    buf[1] = brightness;
    if ((rc = write(file, buf, 2)) != 2) {
        int errsv = errno;
        close(file);
        fprintf(stderr, "ERROR: i2c transaction failed: rc = %d, errno = %s\n", rc, strerror(errsv));
        return false;
    }

    close(file);

    return true;
}

void update()
{
    int _volumePercents = 50;

    dialog_vars.begin_x = 5;
    dialog_vars.begin_y = 5;

    bool isStop = false;
    int ch = -1;
    do {
        ch = 13;
        dialog_gauge2("Volume", "Prompt", 5, 30, _volumePercents, &ch);

        switch(ch) {
        case KEY_UP:
        case KEY_RIGHT:
            ++_volumePercents;
            break;
        case KEY_DOWN:
        case KEY_LEFT:
            --_volumePercents;
            break;
        case KEY_HOME:
            _volumePercents = 100;
            break;
        case KEY_END:
            _volumePercents = 0;
            break;
        case KEY_NPAGE:
            _volumePercents -= 10;
            break;
        case KEY_PPAGE:
            _volumePercents += 10;
            break;
        case 13:
        case KEY_EXIT:
            isStop = true;
            break;
        case 27:
            isStop = true;
            break;
        default:
            break;
        }
        if (_volumePercents > 100) {
            _volumePercents = 100;
        }
        else if (_volumePercents < 0) {
            _volumePercents = 0;
        }
        setBrightness(_volumePercents);
    }
    while (isStop == false);
}

void init()
{
    initscr();
    cbreak();
    raw();
    nonl();
    noecho();
    curs_set(0);
    keypad(stdscr, TRUE);
    nodelay(stdscr, true);
    start_color();

    ::memset(&dialog_state, 0, sizeof(dialog_state));
    ::memset(&dialog_vars, 0, sizeof(dialog_vars));

    dialog_state.output = stderr;
    dialog_state.input = stdin;

    dialog_vars.dlg_clear_screen = TRUE;
    dialog_vars.begin_set = TRUE;
    dialog_vars.nocancel = false;
    dialog_vars.ok_label = (char *)"Ok";
    dialog_vars.cancel_label = (char *)"Close";

    dialog_vars.title = (char *)"LCD brightness";
    dialog_vars.keep_tite = true;
    dialog_vars.backtitle = (char *)"Avicon-14";

    init_dialog(dialog_state.input, dialog_state.output);
    dlg_put_backtitle();

    update();
}

void finit()
{
    echo();
    curs_set(1);
    endwin();
}


int main(int argc, char *argv[])
{
    (void)(argc);
    (void)(argv);

    init();
    finit();

    return 0;
}
